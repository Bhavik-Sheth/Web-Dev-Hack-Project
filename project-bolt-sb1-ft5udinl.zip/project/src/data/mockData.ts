import { Store, VendorType, Product, TimeSlot, Order } from '../types';

export const stores: Store[] = [
  {
    id: '1',
    name: 'FreshStock - Dadar West',
    area: 'Mumbai, 400028',
    pincode: '400028',
    openHours: '6 AM - 8 PM',
    isOpen: true,
  },
  {
    id: '2',
    name: 'FreshStock - Bandra East',
    area: 'Mumbai, 400051',
    pincode: '400051',
    openHours: '7 AM - 9 PM',
    isOpen: true,
  },
  {
    id: '3',
    name: 'FreshStock - Andheri West',
    area: 'Mumbai, 400058',
    pincode: '400058',
    openHours: '6 AM - 10 PM',
    isOpen: false,
  },
];

export const vendorTypes: VendorType[] = [
  { id: '1', name: 'Pani Puri', icon: '🫓' },
  { id: '2', name: 'Chaat', icon: '🥗' },
  { id: '3', name: 'Pav Bhaji', icon: '🍞' },
  { id: '4', name: 'Sandwiches', icon: '🥪' },
  { id: '5', name: 'Momos', icon: '🥟' },
  { id: '6', name: 'Other', icon: '🍽️' },
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Tomato',
    price: 40,
    unit: 'kg',
    image: 'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: true,
  },
  {
    id: '2',
    name: 'Onion',
    price: 30,
    unit: 'kg',
    image: 'https://images.pexels.com/photos/144248/potatoes-vegetables-erdfrucht-bio-144248.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: true,
  },
  {
    id: '3',
    name: 'Potato',
    price: 25,
    unit: 'kg',
    image: 'https://images.pexels.com/photos/2286776/pexels-photo-2286776.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: false,
  },
  {
    id: '4',
    name: 'Coriander',
    price: 20,
    unit: 'bunch',
    image: 'https://images.pexels.com/photos/4198021/pexels-photo-4198021.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: true,
  },
  {
    id: '5',
    name: 'Green Chili',
    price: 80,
    unit: 'kg',
    image: 'https://images.pexels.com/photos/5386666/pexels-photo-5386666.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: true,
  },
  {
    id: '6',
    name: 'Ginger',
    price: 120,
    unit: 'kg',
    image: 'https://images.pexels.com/photos/161556/ginger-plant-asia-rhizome-161556.jpeg?auto=compress&cs=tinysrgb&w=300',
    inStock: true,
  },
];

export const timeSlots: TimeSlot[] = [
  { id: '1', startTime: '8 AM', endTime: '10 AM', available: true },
  { id: '2', startTime: '10 AM', endTime: '12 PM', available: true },
  { id: '3', startTime: '12 PM', endTime: '2 PM', available: true },
  { id: '4', startTime: '2 PM', endTime: '4 PM', available: false },
  { id: '5', startTime: '4 PM', endTime: '6 PM', available: true },
  { id: '6', startTime: '6 PM', endTime: '8 PM', available: true },
];

export const pastOrders: Order[] = [
  {
    id: 'B192',
    pickupId: 'B192',
    items: [
      { product: products[0], quantity: 5 },
      { product: products[1], quantity: 10 },
      { product: products[3], quantity: 3 },
    ],
    total: 1200,
    timeSlot: timeSlots[1],
    store: stores[0],
    date: '24 July 2025',
    status: 'completed',
  },
  {
    id: 'B185',
    pickupId: 'B185',
    items: [
      { product: products[0], quantity: 3 },
      { product: products[4], quantity: 2 },
    ],
    total: 680,
    timeSlot: timeSlots[0],
    store: stores[0],
    date: '22 July 2025',
    status: 'completed',
  },
];