export interface Store {
  id: string;
  name: string;
  area: string;
  pincode: string;
  openHours: string;
  isOpen: boolean;
}

export interface VendorType {
  id: string;
  name: string;
  icon: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  unit: string;
  image: string;
  inStock: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface TimeSlot {
  id: string;
  startTime: string;
  endTime: string;
  available: boolean;
}

export interface Order {
  id: string;
  pickupId: string;
  items: CartItem[];
  total: number;
  timeSlot: TimeSlot;
  store: Store;
  date: string;
  status: 'awaiting-pickup' | 'completed' | 'cancelled';
}

export type Screen = 
  | 'splash'
  | 'select-outlet'
  | 'select-vendor-type'
  | 'browse-products'
  | 'pickup-time'
  | 'order-confirmation'
  | 'past-orders';