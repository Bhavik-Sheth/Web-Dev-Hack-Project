import React from 'react';
import { Store } from 'lucide-react';

interface SplashScreenProps {
  onStart: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onStart }) => {
  return (
    <div className="min-h-screen bg-[#F7F9FC] flex flex-col items-center justify-center px-6">
      <div className="text-center mb-12">
        <div className="inline-flex items-center justify-center w-32 h-32 bg-[#28a745] rounded-3xl mb-8 shadow-xl">
          <Store className="w-16 h-16 text-white" />
        </div>
        <h1 className="text-5xl font-bold text-[#212529] mb-4 font-sans">
          FreshStock
        </h1>
        <p className="text-xl text-[#6c757d] font-medium mb-2">
          Fresh Ingredients, Easy Orders
        </p>
        <p className="text-lg text-[#6c757d] font-medium">
          ताज़ा सामग्री, आसान ऑर्डर
        </p>
      </div>
      
      <button
        onClick={onStart}
        className="w-full max-w-sm bg-[#28a745] text-white text-xl font-bold py-6 px-8 rounded-2xl shadow-xl hover:bg-[#218838] transition-all duration-200 transform hover:scale-105"
      >
        Start Shopping
      </button>
    </div>
  );
};

export default SplashScreen;