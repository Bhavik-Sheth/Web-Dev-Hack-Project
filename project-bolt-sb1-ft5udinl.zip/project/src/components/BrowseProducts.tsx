import React, { useState } from 'react';
import { Menu, Search, Phone, Minus, Plus, ShoppingCart } from 'lucide-react';
import { Store, Product, CartItem, Order } from '../types';

interface BrowseProductsProps {
  store: Store;
  products: Product[];
  currentOrder?: Order;
  onMenuClick: () => void;
  onProductAdd: (product: Product) => void;
  onProductRemove: (product: Product) => void;
  onRequestCall: () => void;
  onViewOrder: () => void;
  cart: CartItem[];
  cartTotal: number;
}

const BrowseProducts: React.FC<BrowseProductsProps> = ({
  store,
  products,
  currentOrder,
  onMenuClick,
  onProductAdd,
  onProductRemove,
  onRequestCall,
  onViewOrder,
  cart,
  cartTotal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getProductQuantity = (productId: string) => {
    const cartItem = cart.find(item => item.product.id === productId);
    return cartItem ? cartItem.quantity : 0;
  };

  const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#F7F9FC]">
      {/* Header */}
      <div className="bg-white shadow-sm px-4 py-4">
        <div className="flex items-center justify-between">
          <button
            onClick={onMenuClick}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <Menu className="w-5 h-5 text-[#212529]" />
          </button>
          <h1 className="text-lg font-semibold text-[#212529] flex-1 text-center mr-10">
            {store.name}
          </h1>
        </div>
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Request Call Button */}
        <button
          onClick={onRequestCall}
          className="w-full bg-white border-3 border-[#28a745] text-[#28a745] py-4 px-6 rounded-2xl font-bold text-lg hover:bg-[#28a745] hover:text-white transition-colors flex items-center justify-center shadow-lg"
        >
          <Phone className="w-6 h-6 mr-3" />
          <div className="text-center">
            <div>Need Help? Request a Call</div>
            <div className="text-sm">मदद चाहिए? कॉल का अनुरोध करें</div>
          </div>
        </button>

        {/* Current Active Order Card */}
        {currentOrder && (
          <div className="bg-white rounded-2xl p-6 shadow-lg border-2 border-[#28a745]">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center mb-3">
                  <div className="w-4 h-4 bg-[#28a745] rounded-full mr-3 animate-pulse" />
                  <h3 className="text-xl font-bold text-[#212529]">
                    Current Order: Awaiting Pickup
                  </h3>
                </div>
                <p className="text-[#6c757d] text-base font-medium">
                  Pickup ID: {currentOrder.pickupId} | Time: {currentOrder.timeSlot.startTime} - {currentOrder.timeSlot.endTime}
                </p>
                <p className="text-[#6c757d] text-sm mt-1">
                  वर्तमान ऑर्डर: पिकअप की प्रतीक्षा में
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-6 h-6 text-[#6c757d]" />
          <input
            type="text"
            placeholder="Search for items..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-4 bg-white border-2 border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#28a745] focus:border-transparent text-lg shadow-lg"
          />
        </div>

        {/* Product Cards */}
        <div className="space-y-4 pb-24">
          {filteredProducts.map((product) => {
            const quantity = getProductQuantity(product.id);
            return (
              <div
                key={product.id}
                className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100"
              >
                <div className="flex items-center space-x-6">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-24 h-24 object-cover rounded-2xl shadow-md"
                  />
                  
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-[#212529] mb-2">
                      {product.name}
                    </h3>
                    <p className="text-lg text-[#212529] font-bold mb-3">
                      ₹{product.price}/{product.unit}
                    </p>
                    <div className="inline-block">
                      <span className={`px-4 py-2 text-sm font-bold rounded-full ${
                        product.inStock 
                          ? 'bg-[#28a745] text-white' 
                          : 'bg-[#6c757d] text-white'
                      }`}>
                        {product.inStock ? 'In Stock • स्टॉक में है' : 'Out of Stock • स्टॉक में नहीं है'}
                      </span>
                    </div>
                  </div>

                  {/* Quantity Selector */}
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => onProductRemove(product)}
                      disabled={quantity === 0 || !product.inStock}
                      className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-200 transition-colors shadow-md"
                    >
                      <Minus className="w-6 h-6 text-[#212529] font-bold" />
                    </button>
                    
                    <span className="text-2xl font-bold text-[#212529] min-w-[3rem] text-center">
                      {quantity}
                    </span>
                    
                    <button
                      onClick={() => onProductAdd(product)}
                      disabled={!product.inStock}
                      className="w-12 h-12 bg-[#28a745] rounded-2xl flex items-center justify-center disabled:bg-[#6c757d] hover:bg-[#218838] transition-colors shadow-md"
                    >
                      <Plus className="w-6 h-6 text-white font-bold" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Floating Action Button */}
      {cartItemCount > 0 && (
        <div className="fixed bottom-6 right-6">
          <button
            onClick={onViewOrder}
            className="bg-[#28a745] text-white px-8 py-5 rounded-3xl shadow-xl hover:bg-[#218838] transition-all duration-200 flex items-center space-x-3 hover:scale-105"
          >
            <ShoppingCart className="w-6 h-6" />
            <span className="font-bold text-lg">
              <div>View Order ({cartItemCount})</div>
              <div>₹{cartTotal}</div>
            </span>
          </button>
        </div>
      )}
    </div>
  );
};

export default BrowseProducts;