import React from 'react';
import { ArrowLeft, RefreshCw, Clock, MapPin } from 'lucide-react';
import { Order } from '../types';

interface PastOrdersProps {
  orders: Order[];
  onBack: () => void;
  onReorder: (order: Order) => void;
}

const PastOrders: React.FC<PastOrdersProps> = ({ orders, onBack, onReorder }) => {
  return (
    <div className="min-h-screen bg-[#F7F9FC]">
      <div className="bg-white shadow-sm px-4 py-4">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-[#212529]" />
          </button>
          <h1 className="text-xl font-semibold text-[#212529]">My Past Orders</h1>
          <p className="text-sm text-[#6c757d] mt-1">मेरे पुराने ऑर्डर</p>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4">
        {orders.map((order) => (
          <div
            key={order.id}
            className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100"
          >
            <div className="flex items-start justify-between mb-6">
              <div>
                <h3 className="text-xl font-bold text-[#212529] mb-2">
                  Order #{order.id}
                </h3>
                <p className="text-[#6c757d] text-base font-medium mb-3">{order.date}</p>
                
                <div className="flex items-center text-[#6c757d] text-base mb-2">
                  <Clock className="w-5 h-5 mr-3" />
                  <span>{order.timeSlot.startTime} - {order.timeSlot.endTime}</span>
                </div>
                
                <div className="flex items-center text-[#6c757d] text-base">
                  <MapPin className="w-5 h-5 mr-3" />
                  <span>{order.store.name}</span>
                </div>
              </div>
              
              <div className="text-right">
                <span className={`px-4 py-2 text-sm font-bold rounded-full ${
                  order.status === 'completed' 
                    ? 'bg-[#28a745] text-white'
                    : order.status === 'awaiting-pickup'
                    ? 'bg-blue-500 text-white'
                    : 'bg-[#dc3545] text-white'
                }`}>
                  {order.status === 'completed' ? 'Completed' : 
                   order.status === 'awaiting-pickup' ? 'Awaiting Pickup' : 'Cancelled'}
                </span>
              </div>
            </div>

            <div className="mb-6">
              <p className="text-[#6c757d] text-base font-medium mb-3">Items:</p>
              <p className="text-[#212529] text-lg font-medium">
                {order.items.map(item => item.product.name).join(', ')}...
              </p>
            </div>

            <div className="flex items-center justify-between pt-6 border-t-2 border-gray-200">
              <span className="text-xl font-bold text-[#212529]">
                Total: ₹{order.total}
              </span>
              
              <button
                onClick={() => onReorder(order)}
                className="bg-[#28a745] text-white px-6 py-3 rounded-2xl font-bold hover:bg-[#218838] transition-colors flex items-center shadow-lg"
              >
                <RefreshCw className="w-5 h-5 mr-2" />
                <div className="text-center">
                  <div>Reorder</div>
                  <div className="text-xs">फिर से ऑर्डर करें</div>
                </div>
              </button>
            </div>
          </div>
        ))}

        {orders.length === 0 && (
          <div className="text-center py-12">
            <div className="text-8xl mb-6">📦</div>
            <h3 className="text-2xl font-bold text-[#212529] mb-3">No Orders Yet</h3>
            <p className="text-lg text-[#6c757d] mb-2">Your order history will appear here</p>
            <p className="text-base text-[#6c757d]">अभी तक कोई ऑर्डर नहीं</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PastOrders;