import React from 'react';
import { CheckCircle, MapPin, Clock, Home, History } from 'lucide-react';
import { Order } from '../types';

interface OrderConfirmationProps {
  order: Order;
  onGoHome: () => void;
  onViewOrders: () => void;
}

const OrderConfirmation: React.FC<OrderConfirmationProps> = ({
  order,
  onGoHome,
  onViewOrders,
}) => {
  return (
    <div className="min-h-screen bg-[#F7F9FC] px-4 py-8">
      <div className="max-w-md mx-auto">
        {/* Success Message */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-28 h-28 bg-[#28a745] rounded-3xl mb-6 shadow-xl">
            <CheckCircle className="w-16 h-16 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-[#212529] mb-3">
            Order Placed!
          </h1>
          <p className="text-xl text-[#6c757d] font-semibold">
            ऑर्डर दिया गया!
          </p>
        </div>

        {/* Pickup ID Display */}
        <div className="bg-white rounded-3xl p-8 shadow-xl border-2 border-[#28a745] mb-8 text-center">
          <p className="text-[#6c757d] text-lg font-semibold mb-3">Pickup ID:</p>
          <p className="text-[#6c757d] text-sm mb-4">पिकअप आईडी:</p>
          <h2 className="text-7xl font-bold text-[#28a745] mb-6">
            {order.pickupId}
          </h2>
          <p className="text-[#6c757d] text-base font-medium">
            Show this ID when collecting your order
          </p>
          <p className="text-[#6c757d] text-sm mt-2">
            अपना ऑर्डर लेते समय यह आईडी दिखाएं
          </p>
        </div>

        {/* Order Summary Card */}
        <div className="bg-white rounded-3xl p-8 shadow-xl border border-gray-100 mb-8">
          <h3 className="text-xl font-bold text-[#212529] mb-2">Order Summary</h3>
          <p className="text-sm text-[#6c757d] mb-6">ऑर्डर सारांश</p>
          
          <div className="space-y-4 mb-6">
            {order.items.map((item, index) => (
              <div key={index} className="flex justify-between items-center py-2">
                <span className="text-[#212529] font-medium text-lg">
                  {item.product.name} - {item.quantity} {item.product.unit}
                </span>
                <span className="font-bold text-[#212529] text-lg">
                  ₹{item.product.price * item.quantity}
                </span>
              </div>
            ))}
          </div>
          
          <div className="border-t-2 border-gray-200 pt-4 mb-6">
            <div className="flex justify-between items-center">
              <span className="text-xl font-bold text-[#212529]">Total:</span>
              <span className="text-2xl font-bold text-[#28a745]">₹{order.total}</span>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center text-[#6c757d] text-lg">
              <Clock className="w-6 h-6 mr-4" />
              <span className="font-medium">Pickup Time: {order.timeSlot.startTime} - {order.timeSlot.endTime}</span>
            </div>
            <div className="flex items-center text-[#6c757d] text-lg">
              <MapPin className="w-6 h-6 mr-4" />
              <span className="font-medium">At: {order.store.name}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={onGoHome}
            className="w-full bg-[#28a745] text-white text-xl font-bold py-6 px-8 rounded-2xl shadow-xl hover:bg-[#218838] transition-colors flex items-center justify-center"
          >
            <Home className="w-6 h-6 mr-3" />
            <div className="text-center">
              <div>Go to Home</div>
              <div className="text-sm font-medium">होम पर जाएं</div>
            </div>
          </button>
          
          <button
            onClick={onViewOrders}
            className="w-full bg-white border-3 border-[#28a745] text-[#28a745] text-xl font-bold py-6 px-8 rounded-2xl hover:bg-[#28a745] hover:text-white transition-colors flex items-center justify-center shadow-lg"
          >
            <History className="w-6 h-6 mr-3" />
            <div className="text-center">
              <div>View My Orders</div>
              <div className="text-sm font-medium">मेरे ऑर्डर देखें</div>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmation;