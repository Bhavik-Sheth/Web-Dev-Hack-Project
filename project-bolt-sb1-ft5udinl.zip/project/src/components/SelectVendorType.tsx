import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { VendorType } from '../types';

interface SelectVendorTypeProps {
  vendorTypes: VendorType[];
  onBack: () => void;
  onSelectVendorType: (vendorType: VendorType) => void;
}

const SelectVendorType: React.FC<SelectVendorTypeProps> = ({ 
  vendorTypes, 
  onBack, 
  onSelectVendorType 
}) => {
  return (
    <div className="min-h-screen bg-[#F7F9FC]">
      <div className="bg-white shadow-sm px-4 py-4">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-[#212529]" />
          </button>
          <h1 className="text-xl font-semibold text-[#212529]">What do you sell?</h1>
          <p className="text-sm text-[#6c757d] mt-1">आप क्या बेचते हैं?</p>
        </div>
      </div>

      <div className="px-4 py-6">
        <div className="grid grid-cols-2 gap-6">
          {vendorTypes.map((vendorType) => (
            <div
              key={vendorType.id}
              onClick={() => onSelectVendorType(vendorType)}
              className="bg-white rounded-3xl p-10 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-200 cursor-pointer hover:scale-[1.05] aspect-square flex flex-col items-center justify-center"
            >
              <div className="text-6xl mb-6">
                {vendorType.icon}
              </div>
              <h3 className="text-xl font-bold text-[#212529] text-center leading-tight">
                {vendorType.name}
              </h3>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SelectVendorType;