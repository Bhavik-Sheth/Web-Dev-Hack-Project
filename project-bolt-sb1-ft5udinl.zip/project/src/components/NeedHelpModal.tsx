import React, { useState } from 'react';
import { X, Phone } from 'lucide-react';

interface NeedHelpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (name: string, phone: string) => void;
}

const NeedHelpModal: React.FC<NeedHelpModalProps> = ({ isOpen, onClose, onSubmit }) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && phone.trim()) {
      onSubmit(name.trim(), phone.trim());
      setName('');
      setPhone('');
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-3xl p-8 w-full max-w-md shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-[#212529]">Request a Call</h2>
            <p className="text-sm text-[#6c757d] mt-1">कॉल का अनुरोध करें</p>
          </div>
          <button
            onClick={onClose}
            className="p-3 hover:bg-gray-100 rounded-2xl transition-colors"
          >
            <X className="w-6 h-6 text-[#6c757d]" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-base font-bold text-[#212529] mb-3">
              Name
            </label>
            <p className="text-sm text-[#6c757d] mb-2">नाम</p>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-6 py-4 bg-white border-2 border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#28a745] focus:border-transparent text-lg shadow-lg"
              placeholder="Enter your name"
              required
            />
          </div>

          <div>
            <label htmlFor="phone" className="block text-base font-bold text-[#212529] mb-3">
              Phone Number
            </label>
            <p className="text-sm text-[#6c757d] mb-2">फोन नंबर</p>
            <input
              type="tel"
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-6 py-4 bg-white border-2 border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-[#28a745] focus:border-transparent text-lg shadow-lg"
              placeholder="Enter your phone number"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-[#28a745] text-white text-xl font-bold py-5 px-8 rounded-2xl shadow-xl hover:bg-[#218838] transition-colors flex items-center justify-center"
          >
            <Phone className="w-6 h-6 mr-3" />
            <div className="text-center">
              <div>Submit Request</div>
              <div className="text-sm font-medium">अनुरोध भेजें</div>
            </div>
          </button>
        </form>
      </div>
    </div>
  );
};

export default NeedHelpModal;