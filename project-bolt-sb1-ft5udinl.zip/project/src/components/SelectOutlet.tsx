import React from 'react';
import { ArrowLeft, Clock, MapPin } from 'lucide-react';
import { Store } from '../types';

interface SelectOutletProps {
  stores: Store[];
  onBack?: () => void;
  onSelectStore: (store: Store) => void;
}

const SelectOutlet: React.FC<SelectOutletProps> = ({ stores, onBack, onSelectStore }) => {
  return (
    <div className="min-h-screen bg-[#F7F9FC]">
      <div className="bg-white shadow-sm px-4 py-4">
        <div className="flex items-center">
          {onBack && (
            <button
              onClick={onBack}
              className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-[#212529]" />
            </button>
          )}
          <h1 className="text-xl font-semibold text-[#212529]">Select a Store</h1>
          <p className="text-sm text-[#6c757d] mt-1">स्टोर चुनें</p>
        </div>
      </div>

      <div className="px-4 py-6 space-y-4">
        {stores.map((store) => (
          <div
            key={store.id}
            onClick={() => onSelectStore(store)}
            className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-200 cursor-pointer hover:scale-[1.02]"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="text-xl font-bold text-[#212529] mb-3">
                  {store.name}
                </h3>
                
                <div className="flex items-center text-[#6c757d] mb-3">
                  <MapPin className="w-5 h-5 mr-3" />
                  <span className="text-base font-medium">{store.area}</span>
                </div>
                
                <div className="flex items-center text-[#6c757d] mb-4">
                  <Clock className="w-5 h-5 mr-3" />
                  <span className="text-base font-medium">Open: {store.openHours}</span>
                </div>
                
                <div className="flex items-center">
                  <div className={`w-3 h-3 rounded-full mr-3 ${
                    store.isOpen ? 'bg-[#28a745]' : 'bg-[#dc3545]'
                  }`} />
                  <span className={`text-base font-bold ${
                    store.isOpen ? 'text-[#28a745]' : 'text-[#dc3545]'
                  }`}>
                    {store.isOpen ? 'Open Now' : 'Closed'}
                  </span>
                  <span className={`ml-2 text-sm ${
                    store.isOpen ? 'text-[#28a745]' : 'text-[#dc3545]'
                  }`}>
                    {store.isOpen ? '• खुला है' : '• बंद है'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SelectOutlet;