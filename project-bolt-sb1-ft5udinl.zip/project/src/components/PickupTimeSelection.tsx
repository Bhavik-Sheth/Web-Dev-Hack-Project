import React, { useState } from 'react';
import { ArrowLeft, Calendar } from 'lucide-react';
import { TimeSlot } from '../types';

interface PickupTimeSelectionProps {
  timeSlots: TimeSlot[];
  onBack: () => void;
  onConfirmSlot: (timeSlot: TimeSlot) => void;
}

const PickupTimeSelection: React.FC<PickupTimeSelectionProps> = ({
  timeSlots,
  onBack,
  onConfirmSlot,
}) => {
  const [selectedSlot, setSelectedSlot] = useState<TimeSlot | null>(null);

  const handleConfirm = () => {
    if (selectedSlot) {
      onConfirmSlot(selectedSlot);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7F9FC]">
      <div className="bg-white shadow-sm px-4 py-4">
        <div className="flex items-center">
          <button
            onClick={onBack}
            className="mr-4 p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-[#212529]" />
          </button>
          <h1 className="text-xl font-semibold text-[#212529]">Choose Pickup Time</h1>
          <p className="text-sm text-[#6c757d] mt-1">पिकअप का समय चुनें</p>
        </div>
      </div>

      <div className="px-4 py-6">
        <div className="flex items-center mb-8 bg-white rounded-2xl p-6 shadow-lg">
          <Calendar className="w-8 h-8 text-[#28a745] mr-4" />
          <span className="text-xl font-bold text-[#212529]">
            Today, 26 July
          </span>
        </div>

        <div className="space-y-3 mb-8">
          {timeSlots.map((slot) => (
            <button
              key={slot.id}
              onClick={() => slot.available && setSelectedSlot(slot)}
              disabled={!slot.available}
              className={`w-full p-6 rounded-2xl border-3 font-bold text-lg transition-all duration-200 shadow-lg ${
                selectedSlot?.id === slot.id
                  ? 'bg-[#28a745] text-white border-[#28a745]'
                  : slot.available
                  ? 'bg-white text-[#212529] border-gray-300 hover:border-[#28a745] hover:bg-green-50'
                  : 'bg-gray-100 text-[#6c757d] border-gray-300 cursor-not-allowed'
              }`}
            >
              {slot.startTime} – {slot.endTime}
              {!slot.available && <span className="ml-2">(Full)</span>}
            </button>
          ))}
        </div>

        <button
          onClick={handleConfirm}
          disabled={!selectedSlot}
          className="w-full bg-[#28a745] text-white text-xl font-bold py-6 px-8 rounded-2xl shadow-xl disabled:bg-[#6c757d] disabled:cursor-not-allowed hover:bg-[#218838] transition-colors"
        >
          <div>Confirm Slot</div>
          <div className="text-sm font-medium">स्लॉट की पुष्टि करें</div>
        </button>
      </div>
    </div>
  );
};

export default PickupTimeSelection;