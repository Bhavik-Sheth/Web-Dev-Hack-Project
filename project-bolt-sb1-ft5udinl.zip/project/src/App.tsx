import React, { useState } from 'react';
import SplashScreen from './components/SplashScreen';
import SelectOutlet from './components/SelectOutlet';
import SelectVendorType from './components/SelectVendorType';
import BrowseProducts from './components/BrowseProducts';
import PickupTimeSelection from './components/PickupTimeSelection';
import OrderConfirmation from './components/OrderConfirmation';
import PastOrders from './components/PastOrders';
import NeedHelpModal from './components/NeedHelpModal';
import { stores, vendorTypes, products, timeSlots, pastOrders } from './data/mockData';
import { Screen, Store, VendorType, Product, CartItem, TimeSlot, Order } from './types';

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [selectedStore, setSelectedStore] = useState<Store | null>(null);
  const [selectedVendorType, setSelectedVendorType] = useState<VendorType | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<TimeSlot | null>(null);
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [completedOrders, setCompletedOrders] = useState<Order[]>(pastOrders);
  const [showHelpModal, setShowHelpModal] = useState(false);

  const cartTotal = cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);

  const handleStart = () => {
    setCurrentScreen('select-outlet');
  };

  const handleSelectStore = (store: Store) => {
    setSelectedStore(store);
    setCurrentScreen('select-vendor-type');
  };

  const handleSelectVendorType = (vendorType: VendorType) => {
    setSelectedVendorType(vendorType);
    setCurrentScreen('browse-products');
  };

  const handleProductAdd = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.product.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prevCart, { product, quantity: 1 }];
      }
    });
  };

  const handleProductRemove = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.product.id === product.id);
      if (existingItem && existingItem.quantity > 1) {
        return prevCart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity - 1 }
            : item
        );
      } else {
        return prevCart.filter(item => item.product.id !== product.id);
      }
    });
  };

  const handleViewOrder = () => {
    setCurrentScreen('pickup-time');
  };

  const handleConfirmSlot = (timeSlot: TimeSlot) => {
    setSelectedTimeSlot(timeSlot);
    
    // Create new order
    const newOrder: Order = {
      id: 'A47',
      pickupId: 'A47',
      items: [...cart],
      total: cartTotal,
      timeSlot,
      store: selectedStore!,
      date: new Date().toLocaleDateString('en-GB', { 
        day: 'numeric', 
        month: 'long', 
        year: 'numeric' 
      }),
      status: 'awaiting-pickup',
    };

    setCurrentOrder(newOrder);
    setCart([]); // Clear cart
    setCurrentScreen('order-confirmation');
  };

  const handleGoHome = () => {
    setCurrentScreen('browse-products');
  };

  const handleViewOrders = () => {
    setCurrentScreen('past-orders');
  };

  const handleMenuClick = () => {
    setCurrentScreen('past-orders');
  };

  const handleReorder = (order: Order) => {
    // Add order items to cart
    setCart(order.items);
    setCurrentScreen('browse-products');
  };

  const handleRequestCall = () => {
    setShowHelpModal(true);
  };

  const handleSubmitHelpRequest = (name: string, phone: string) => {
    // In a real app, this would send the request to a server
    console.log('Help request submitted:', { name, phone });
    // Show success message or handle the request
  };

  const handleBack = () => {
    switch (currentScreen) {
      case 'select-outlet':
        setCurrentScreen('splash');
        break;
      case 'select-vendor-type':
        setCurrentScreen('select-outlet');
        break;
      case 'pickup-time':
        setCurrentScreen('browse-products');
        break;
      case 'past-orders':
        setCurrentScreen('browse-products');
        break;
      default:
        break;
    }
  };

  return (
    <div className="min-h-screen">
      {currentScreen === 'splash' && (
        <SplashScreen onStart={handleStart} />
      )}

      {currentScreen === 'select-outlet' && (
        <SelectOutlet
          stores={stores}
          onBack={() => setCurrentScreen('splash')}
          onSelectStore={handleSelectStore}
        />
      )}

      {currentScreen === 'select-vendor-type' && (
        <SelectVendorType
          vendorTypes={vendorTypes}
          onBack={handleBack}
          onSelectVendorType={handleSelectVendorType}
        />
      )}

      {currentScreen === 'browse-products' && selectedStore && (
        <BrowseProducts
          store={selectedStore}
          products={products}
          currentOrder={currentOrder}
          onMenuClick={handleMenuClick}
          onProductAdd={handleProductAdd}
          onProductRemove={handleProductRemove}
          onRequestCall={handleRequestCall}
          onViewOrder={handleViewOrder}
          cart={cart}
          cartTotal={cartTotal}
        />
      )}

      {currentScreen === 'pickup-time' && (
        <PickupTimeSelection
          timeSlots={timeSlots}
          onBack={handleBack}
          onConfirmSlot={handleConfirmSlot}
        />
      )}

      {currentScreen === 'order-confirmation' && currentOrder && (
        <OrderConfirmation
          order={currentOrder}
          onGoHome={handleGoHome}
          onViewOrders={handleViewOrders}
        />
      )}

      {currentScreen === 'past-orders' && (
        <PastOrders
          orders={completedOrders}
          onBack={handleBack}
          onReorder={handleReorder}
        />
      )}

      <NeedHelpModal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
        onSubmit={handleSubmitHelpRequest}
      />
    </div>
  );
}

export default App;